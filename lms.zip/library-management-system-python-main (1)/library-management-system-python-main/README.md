# library-management-system
This is a simple library management system using python with text file for storing data.
